import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr=new Scanner(System.in);
        int x,y;
        System.out.println("Введите целое число");
        x = scr.nextInt();
        y=x>>1;
        System.out.println(y);




    }
}