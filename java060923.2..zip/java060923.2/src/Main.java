import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr=new Scanner(System.in);
        double a,b,s;
        System.out.println("стоимость товара");
        a= scr.nextDouble();
        System.out.println("наличные");
        b= scr.nextDouble();
        s=b-a;
        double euro=(int)s;
        System.out.println(euro+" евро");
        double cent=(s*100)%100;
        System.out.println(cent+" центов");

    }
}