public class Main {
    public static void main(String[] args) {
        boolean isYearFinished=true;
        boolean isGoodWeather=true;
        boolean isBoughtRaincoats=true;
        boolean isJimFree=true;
        boolean isKateComeBack=true;
        boolean isTravelhappened=(isGoodWeather || isBoughtRaincoats)&&isYearFinished&&
                (isJimFree^isKateComeBack);
        System.out.println(isTravelhappened);



    }
}